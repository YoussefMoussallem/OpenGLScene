#include"Circular_Pipe.h"
#include"Square.h"
Circular_Pipe::Circular_Pipe(float radius,float cr,int res,Material material) {
	this->material = material;

	float theta = 0;
	Circle circle(res, radius, vec3(1,1,1), vec3(1,1,1), vec3(0,0,0));
	float dtheta =( 2 * M_PI) / (res);

	for (Vertex vertex : circle.vertices) {
		Circle c(res, cr, vec3(1,1,1), vec3(1,1,1), vec3(0,0,0));

		for (Vertex v : c.vertices) {
			mat4 model = mat4(1.0);
			model = rotate(model, (float)radians(90.0),vec3(radius*cos(theta),radius*sin(theta),0));
			vec4 temp = model * vec4(v.pos, 1);
			v.pos = vec3(temp.x, temp.y, temp.z);
			v.pos.x = v.pos.x + radius;
			v.pos.x += radius * cos(theta);
			v.pos.y += radius * sin(theta);
			vertices.push_back(v);
		}
		theta += dtheta;
	}

	int A, B, C, D;
	for (int i = 0; i < res; i++) {
		for (int j = 0; j < res; j++) {
			A = i * res + j;
			B = i * res + (j + 1) % res;
			C = (i + 1) * res + j;
			D = (i + 1) * res + (j + 1) % res;
			indices.push_back(A);
			indices.push_back(D);
			indices.push_back(B);

			indices.push_back(A);
			indices.push_back(C);
			indices.push_back(D);

		}
	}

	for (int j = 0; j < circle.vertices.size(); j++) {
		A = (res) * res + j;
		B = (res) * res + (j + 1) % res;
		C = j;
		D =  (j + 1) % res;
		indices.push_back(A);
		indices.push_back(D);
		indices.push_back(B);

		indices.push_back(A);
		indices.push_back(C);
		indices.push_back(D);

	}

	for (int i = 0; i < indices.size()/3 ; i++) {
		int A, B, C;
		A = indices[3 * i];
		B = indices[3 * i + 1];
		C = indices[3 * i + 2];
		vec3 normal = cross(vertices[C].pos - vertices[B].pos, vertices[A].pos - vertices[C].pos);
		vertices[A].normal = normalize(normal);
		vertices[B].normal = normalize(normal);
		vertices[C].normal = normalize(normal);
	}
	Mesh mesh(vertices, indices, 0, 1);
	meshes.push_back(mesh);
}

void Circular_Pipe::render(Shader shader, vec3 size, vec3 pos, float angle, vec3 axis) {
	mat4 model = mat4(1.0);
	model = translate(model, pos);
	model = rotate(model, (float)(glfwGetTime()*radians(angle)), axis);
	model = scale(model, size);

	shader.setfloat3("material.ambient", material.ambient);
	shader.setfloat3("material.diffuse", material.diffuse);
	shader.setfloat3("material.specular", material.specular);
	shader.setfloat("material.shininess", material.shininess);
	shader.setMatrix4("model", model);
	Model::render(GL_TRIANGLES, shader);
}




