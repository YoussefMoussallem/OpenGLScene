#ifndef Circular_Pipe_H
#define Circular_Pipe_H

#include"Model.h"
#include<vector>
#include"Circle.h"
#include"../inquiries/Material.h"
#define M_PI 3.14159265358979323846
using namespace glm;
class Circular_Pipe :public Model {
	vector<Vertex> vertices;
	vector<GLuint> faces;
	vector<GLuint> indices;
	Material material;
public:
	Circular_Pipe(float radius, float cr, int res,Material material);
	void render(Shader shader, vec3 size, vec3 pos,float angle, vec3 axis);
};
	
#endif // !Circular_Pipe_H

